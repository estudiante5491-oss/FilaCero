/* FILA CERO — script.js
   Interacciones de demostración. No conecta con un servidor. */

document.addEventListener("DOMContentLoaded", () => {
  const menuToggle = document.querySelector(".menu-toggle");
  const mainNav = document.querySelector(".main-nav");

  if (menuToggle && mainNav) {
    menuToggle.addEventListener("click", () => {
      const isOpen = mainNav.classList.toggle("open");
      menuToggle.setAttribute("aria-expanded", String(isOpen));
      menuToggle.setAttribute("aria-label", isOpen ? "Cerrar menú" : "Abrir menú");
    });

    mainNav.querySelectorAll("a").forEach(link => {
      link.addEventListener("click", () => {
        mainNav.classList.remove("open");
        menuToggle.setAttribute("aria-expanded", "false");
        menuToggle.setAttribute("aria-label", "Abrir menú");
      });
    });
  }

  const year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();

  const form = document.getElementById("turn-form");
  const nameInput = document.getElementById("customer-name");
  const queueList = document.getElementById("queue-list");
  const queueCount = document.getElementById("queue-count");
  const currentTurn = document.getElementById("current-turn");
  const currentStatus = document.getElementById("current-status");
  const feedback = document.getElementById("demo-feedback");
  const nextButton = document.getElementById("next-turn");
  const resetButton = document.getElementById("reset-demo");

  let nextNumber = 1;
  let waiting = [];
  let lastCalled = null;

  const formatNumber = number => `A-${String(number).padStart(3, "0")}`;

  function renderQueue() {
    if (!queueList) return;

    queueCount.textContent = `${waiting.length} pendiente${waiting.length === 1 ? "" : "s"}`;

    if (waiting.length === 0) {
      queueList.innerHTML = `
        <div class="empty-state">
          <span>＋</span>
          <strong>La lista está vacía</strong>
          <small>Registra un turno para comenzar la demostración.</small>
        </div>`;
      return;
    }

    queueList.innerHTML = waiting.map(ticket => `
      <div class="queue-item">
        <div class="queue-item-main">
          <span class="queue-code">${ticket.code}</span>
          <span class="queue-name">${escapeHTML(ticket.name)}</span>
        </div>
        <span class="queue-pending">PENDIENTE</span>
      </div>
    `).join("");
  }

  function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, character => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
    })[character]);
  }

  if (form) {
    form.addEventListener("submit", event => {
      event.preventDefault();

      if (waiting.length >= 30) {
        feedback.textContent = "La demostración admite hasta 30 turnos pendientes.";
        return;
      }

      const name = nameInput.value.trim() || "Usuario";
      const ticket = { number: nextNumber, code: formatNumber(nextNumber), name };

      waiting.push(ticket);
      nextNumber += 1;
      nameInput.value = "";
      feedback.textContent = `Turno ${ticket.code} agregado correctamente.`;
      renderQueue();
    });
  }

  if (nextButton) {
    nextButton.addEventListener("click", () => {
      if (waiting.length === 0) {
        feedback.textContent = "No hay turnos pendientes para llamar.";
        return;
      }

      lastCalled = waiting.shift();
      currentTurn.textContent = lastCalled.code;
      currentTurn.classList.add("called");
      currentStatus.textContent = `Atendiendo: ${lastCalled.name}`;
      feedback.textContent = `Se llamó al turno ${lastCalled.code}.`;
      renderQueue();
    });
  }

  if (resetButton) {
    resetButton.addEventListener("click", () => {
      waiting = [];
      nextNumber = 1;
      lastCalled = null;
      currentTurn.textContent = "— — —";
      currentTurn.classList.remove("called");
      currentStatus.textContent = "Aún no se ha llamado un turno";
      feedback.textContent = "La demostración se reinició.";
      renderQueue();
    });
  }

  const contactForm = document.getElementById("contact-form");
  const contactFeedback = document.getElementById("contact-feedback");

  if (contactForm) {
    contactForm.addEventListener("submit", event => {
      event.preventDefault();
      if (!contactForm.reportValidity()) return;

      contactFeedback.textContent =
        "Mensaje de prueba registrado en esta página. Para recibir mensajes reales se necesita conectar un servicio o servidor.";
      contactForm.reset();
    });
  }

  renderQueue();
});
